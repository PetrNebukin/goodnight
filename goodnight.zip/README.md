# BSoDI (codenamed GoodNight) — Blue Screen of Death Invoker
[![.NET](https://github.com/PetrNebukin/goodnight/actions/workflows/dotnet.yml/badge.svg)](https://github.com/PetrNebukin/goodnight/actions/workflows/dotnet.yml)
***
Это приложение способно вызвать критическую ошибку в Windows, засчёт внедрения якобы вредоносного кода в ядро, находящееся в ОЗУ.

**ВНИМАНИЕ!** **Данное приложение распространяется *только для тестирования работы* вышеуказанной системы в результате отказа работы. Использование данного приложения в иных целях не привествуется. Запускайте приложение *на свой страх и риск*!**
